package services;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/* Aplicación para una tienda en la cual queremos almacenar distintos productos a vender y el precio que tendrán
El HashMap tendrá de llave el nombre del producto y de valor el precio. */
public class ProductosService {

    private HashMap<String, Integer> productos;
    private Scanner leer;

    public ProductosService() {
        this.productos = new HashMap<>();
        this.leer = new Scanner(System.in).useDelimiter("\n");
    }

    // Realizar un menú para las funciones básicas [Service];
    public void menu() {
        int opcion;

        do {
            System.out.println("Bienvenido al Menu, seleccione una opcion;\n"
                    + "1. Introducir un Elemento \n"
                    + "2. Modificar precio\n"
                    + "3. Eliminar Producto\n"
                    + "4. Mostrar Productos\n"
                    + "5. Salir");

            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    agregarProductos();
                    break;
                case 2:
                    modificarPrecio();
                    break;
                case 3:
                    eliminarProducto();
                    break;
                case 4:
                    mostrarProductos();
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Valor no valido");
            }
        } while (opcion != 5);

    }

// función put(llave,valor)
    public void agregarProductos() {
        String producto;
        Integer valor;

        System.out.println("Ingrese el nombre del producto");
        producto = leer.next().toUpperCase();
        System.out.println("Ingrese el valor del producto");
        valor = leer.nextInt();

        productos.put(producto, valor);
    }

    /* Eliminar Elementos
Los mapas son los únicos que no podemos eliminar mientras iteramos
Borramos por llave (Nombre del producto) */
    public void eliminarProducto() {
        System.out.println("Ingrese el nombre del producto a eliminar");
        productos.remove(leer.next().toUpperCase()); // cambiar a un leer
    }

    /* Recorrer Coleccion
Para recorrer mapas vamos a tener que usar el objeto Map.Entry en el for each.
A través del entry vamos a traer los valores y las llaves, si no,
podemos tener un for each para cada parte de nuestro mapa sin utilizar el objeto Map.Entry. */
    public void mostrarProductos() {
        for (Map.Entry<String, Integer> entry : productos.entrySet()) {
            System.out.println("Producto = " + entry.getKey() + ", valor = " + entry.getValue());
        }
    }

    // .replace()
    public void modificarPrecio() {
        System.out.println("Ingrese el nombre del producto a modificar el precio");
        String nombreProducto = leer.next().toUpperCase();
        System.out.println("Ingrese el precio actualizado");
        productos.replace(nombreProducto, leer.nextInt());
    }
}
