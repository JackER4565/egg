package main;

import services.ProductosService;

public class Main {

    public static void main(String[] args) {
        ProductosService ps = new ProductosService();
        ps.menu();

    }

}
