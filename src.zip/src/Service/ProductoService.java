package Service;

import Entity.Producto;
import Entity.Tienda;
import java.util.ArrayList;
import java.util.Scanner;

public class ProductoService {

    ArrayList<Producto> prod = new ArrayList<>();

    Scanner sc = new Scanner(System.in).useDelimiter("\n");

    public void crear() {

        Producto product = new Producto();

        System.out.println("Ingrese el nombre del producto, por favor");
        product.setNombre(sc.next());

        System.out.println("Ingrese la categoria del producto, por favor");
        product.setCategoria(sc.next());

        System.out.println("Ingrese el precio del producto, por favor");
        product.setPrecio(sc.nextDouble());

        System.out.println("Ingrese la cantidad del producto, por favor");
        product.setCantidad(sc.nextInt());

        prod.add(product);

    }

    public void mostrar() {

        for (Producto producto : prod) {
            System.out.println(producto.toString());
        }

    }

    public void eliminar() {

        System.out.println("Que producto desea eliminar?");
        String prodEliminar = sc.next();

        for (Producto producto : prod) {
            if (producto.getNombre().equalsIgnoreCase(prodEliminar)) {
                prod.remove(producto);
                break;
            }
            
        }

    }
    
//        public void buscarElimar(String varElegido) {
//        // Uso el iterador, porque si uso FOREACH da error
//        Iterator<PersonaArrayList> it = nuevaLista.iterator();
//        while (it.hasNext()) {
//            if (it.next().getApellido().equals(varElegido)) { // Si se cumple la condicion de encontrar "Ese apellido elegido,lo elimina)
//                it.remove();
//            }
//        }
//    }

    public void menu() {

        int menuPpal = 0;

        Tienda nuevaTienda = new Tienda(prod);

        nuevaTienda.mostrarProducto();

        nuevaTienda.mostrarProducto();

        do {

            int tamanioLista = prod.size();

            String opciones = "Ingrese opcion: \n";
            String model1 = "1. Agregar producto\n";
            String model2 = !(tamanioLista > 0) ? "" : "2. Obtener Productos \n3. Actualizar Productos \n4. Eliminar Productos \n5. Vender Productos \n6. Reponer Productos";

            // 'Operador ternario' funciona 1ra parte hasta ? como el if, hasta los : si es true, hceme esto
            // Despues : es como un else, sino haceme esto otro
            System.out.println(opciones + model1 + model2);

            menuPpal = sc.nextInt();

            switch (menuPpal) {
                case 1:
                    crear();
                    break;
                case 2:
                    mostrar();
                    break;
                case 3:
                    // TODO metodo actualizar prods
                    break;
                case 4:
                    eliminar();
                    break;
                case 5:
                    nuevaTienda.venta();
                    break;
                case 6:
                    nuevaTienda.reposición();

                    break;

                case 7:
                    System.exit(0);  // Para salir del menu
                    break;

                default:
                    System.out.println("Ingrese una opcion correcta, por favor (1 a 7)");
            }

        } while (menuPpal > 0 && menuPpal < 8);

    }

}
